import yaml
import os
import logging
import asyncio
import oracledb
import asyncpg
from fastapi import FastAPI, HTTPException, Depends, Request, Body
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.openapi.docs import get_swagger_ui_html
from typing import Dict, Any

from database import DatabasePool
from models import SQLRequest, ExecuteResponse, QueryResponse, ErrorResponse

# --- 配置 ---
CONFIG_FILE = "config.yaml" # 配置文件名

def load_config() -> Dict[str, Any]:
    """从 YAML 文件加载配置。"""
    if not os.path.exists(CONFIG_FILE):
        raise FileNotFoundError(f"配置文件 '{CONFIG_FILE}' 未找到。")
    with open(CONFIG_FILE, 'r', encoding='utf-8') as f: # 指定utf-8编码
        config = yaml.safe_load(f)
    if not config or 'databases' not in config:
        raise ValueError(f"'{CONFIG_FILE}' 中的配置格式无效。缺少 'databases' 键。")
    return config

# --- 日志设置 ---
# 配置日志记录器
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__) # 获取当前模块的 logger

# --- 全局状态 ---
# 用于存储数据库连接池实例的字典，键是 config.yaml 中的 db_name
db_pools: Dict[str, DatabasePool] = {}
# 用于存储加载的应用程序配置
app_config: Dict[str, Any] = {}

# --- FastAPI 应用实例 ---
app = FastAPI(
    title="API执行SQL小工具",
    description="通过API对数据库执行SQL命令。**警告：** 由于安全风险，请极其谨慎使用。",
    version="1.0.0",
    author="Zhangzhiao",
    # responses={ # 可选：为所有路径定义通用错误响应模型
    #     500: {"model": ErrorResponse, "description": "内部服务器错误"},
    #     400: {"model": ErrorResponse, "description": "错误的请求"},
    #     404: {"model": ErrorResponse, "description": "未找到资源"},
    #     503: {"model": ErrorResponse, "description": "服务不可用"}
    # }
)

# --- 启动和关闭事件处理 ---
@app.on_event("startup")
async def startup_event():
    """在应用启动时加载配置并初始化数据库连接池。"""
    global app_config, db_pools
    logger.info("应用程序启动中...")
    try:
        app_config = load_config() # 加载配置
        db_configs = app_config.get('databases', {}) # 获取数据库配置部分
        if not db_configs:
            logger.warning("配置中未找到数据库定义。")
            return

        logger.info(f"找到 {len(db_configs)} 个数据库配置。")
        init_tasks = [] # 存储初始化协程任务
        temp_pools = {} # 临时存储创建的 Pool 对象

        # 为每个数据库配置创建 DatabasePool 实例并准备初始化
        for name, conf in db_configs.items():
            db_type = conf.get('type')
            if not db_type:
                logger.error(f"数据库配置 '{name}' 缺少 'type' 字段。跳过。")
                continue

            logger.info(f"正在为 '{name}' ({db_type}) 创建 DatabasePool 实例...")
            pool = DatabasePool(db_name=name, db_type=db_type, db_config=conf)
            temp_pools[name] = pool # 暂存 pool 实例
            init_tasks.append(pool.init_pool()) # 将 init_pool 协程添加到任务列表

        # 并发执行所有数据库连接池的初始化
        logger.info("开始并发初始化所有数据库连接池...")
        # return_exceptions=True 让 gather 在遇到异常时不立即停止，而是收集所有结果/异常
        results = await asyncio.gather(*init_tasks, return_exceptions=True)

        # 处理初始化结果，将成功的池添加到全局字典
        successful_pools = 0
        pool_names = list(temp_pools.keys()) # 获取与 results 对应的 pool 名称列表
        for i, result in enumerate(results):
            pool_name = pool_names[i] # 当前结果对应的数据库名称
            if isinstance(result, Exception):
                 # 如果结果是异常对象，表示该池初始化失败
                 logger.error(f"初始化连接池 '{pool_name}' 失败: {result}", exc_info=result)
            elif result is True: # 检查来自 init_pool 的成功标志
                 # 如果结果是 True，表示初始化成功
                 db_pools[pool_name] = temp_pools[pool_name] # 将成功的池加入全局字典
                 successful_pools += 1
                 logger.info(f"成功初始化连接池 '{pool_name}'。")
            else:
                 # 如果 init_pool 返回 False 但没有抛出异常 (不太可能，但以防万一)
                 logger.error(f"连接池 '{pool_name}' 的初始化报告失败，但未引发异常。")


        logger.info(f"启动完成。成功初始化 {successful_pools}/{len(db_configs)} 个数据库连接池。")
        # 如果有配置但一个都没成功，发出警告
        if successful_pools == 0 and len(db_configs) > 0:
             logger.warning("没有任何数据库连接池成功初始化。API 端点可能会失败。")

    except FileNotFoundError as e:
        logger.error(f"配置错误: {e}", exc_info=True)
        # 如果配置是必需的，可以选择在此处完全阻止应用启动
        # raise RuntimeError("加载配置失败，停止应用程序。") from e
    except ValueError as e:
        logger.error(f"配置错误: {e}", exc_info=True)
        # raise RuntimeError("配置无效，停止应用程序。") from e
    except Exception as e:
        logger.error(f"启动过程中发生意外错误: {e}", exc_info=True)
        # raise RuntimeError("关键启动错误。") from e


@app.on_event("shutdown")
async def shutdown_event():
    """在应用关闭时关闭所有数据库连接池。"""
    logger.info("应用程序关闭中...")
    close_tasks = [pool.close() for pool_name, pool in db_pools.items()] # 创建关闭任务列表
    if close_tasks:
        logger.info(f"正在关闭 {len(close_tasks)} 个数据库连接池...")
        # 并发关闭所有池，并收集结果/异常
        results = await asyncio.gather(*close_tasks, return_exceptions=True)
        for i, result in enumerate(results):
            pool_name = list(db_pools.keys())[i] # 获取对应的池名称
            if isinstance(result, Exception):
                 logger.error(f"关闭连接池 '{pool_name}' 时出错: {result}", exc_info=result)
    logger.info("关闭完成。")

# --- 依赖项：根据请求体中的 db_name 获取数据库连接池 ---
async def get_db_pool_from_request(request: SQLRequest) -> DatabasePool:
    """
    FastAPI 依赖项：从请求体中提取 db_name 并获取相应的 DatabasePool 实例。
    """
    db_name = request.db_name
    if not db_name:
         logger.warning("请求体中缺少 'db_name' 字段。")
         raise HTTPException(status_code=400, detail="请求体中必须包含 'db_name' 字段。")

    pool = db_pools.get(db_name) # 从全局字典中查找池
    if not pool:
        # 如果配置中就没有这个名字，或者启动时初始化失败了
        logger.error(f"未找到或未初始化名为 '{db_name}' 的数据库连接池。")
        raise HTTPException(
            status_code=404, # Not Found 更合适
            detail=f"数据库配置 '{db_name}' 未找到或初始化失败。"
        )
    if not pool.pool: # 再次检查内部的 pool 对象是否真的被创建了 (捕获 init 失败的情况)
         logger.error(f"数据库连接池 '{db_name}' 对象内部为空，可能初始化失败。")
         raise HTTPException(
             status_code=503, # Service Unavailable
             detail=f"数据库连接池 '{db_name}' 当前不可用（可能初始化失败）。"
        )
    return pool # 返回找到的连接池实例

# --- API 端点 ---

# 通用异常处理器，捕获未被特定处理器处理的异常
@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    """处理所有未被捕获的通用异常，返回 500 错误。"""
    logger.error(f"处理请求 {request.method} {request.url.path} 时发生未捕获异常: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        # 使用 ErrorResponse 模型来标准化错误输出
        content=ErrorResponse(message=f"发生内部服务器错误: {type(exc).__name__}").dict(),
    )

@app.post("/execute",
          response_model=ExecuteResponse, # 定义成功的响应模型
          responses={ # 定义可能的错误响应及其模型
              400: {"model": ErrorResponse, "description": "无效请求 (例如，缺少字段、格式错误)"},
              404: {"model": ErrorResponse, "description": "指定的数据库配置 (db_name) 未找到或未初始化"},
              500: {"model": ErrorResponse, "description": "数据库执行错误或其他内部服务器错误"},
              503: {"model": ErrorResponse, "description": "数据库连接池不可用 (例如，初始化失败)"}
          },
          summary="执行 DML/DDL SQL 语句", # API 文档中的摘要
          description="执行 INSERT, UPDATE, DELETE, CREATE TABLE 等修改数据或模式的 SQL 语句。返回受影响的行数。" # API 文档中的详细描述
)
async def execute_sql(
    # 使用 Body(...) 明确指示 request 来自请求体
    request: SQLRequest = Body(...),
    # 使用 Depends 来注入通过 get_db_pool_from_request 获取的连接池
    pool: DatabasePool = Depends(get_db_pool_from_request)
):
    """
    处理 /execute POST 请求。

    **安全警告:** 请极度谨慎使用此端点。务必在生产环境中实施严格的身份验证、
    授权和输入验证机制，以防止 SQL 注入等安全风险。
    """
    logger.info(f"收到 /execute 请求，目标数据库: '{request.db_name}', SQL: '{request.sql[:100]}...'") # 日志记录 SQL 前缀
    try:
        # 调用连接池的 execute 方法执行 SQL
        rows_affected = await pool.execute(request.sql, request.params)
        # 返回成功的响应
        return ExecuteResponse(message="命令执行成功。", rows_affected=rows_affected)
    except (oracledb.DatabaseError, asyncpg.PostgresError) as db_err:
        # 捕获特定于数据库驱动的错误
        logger.error(f"在 '{request.db_name}' 上执行语句时数据库错误: {db_err}", exc_info=True) # 记录完整堆栈
        # 构造包含具体错误信息的响应
        error_detail = f"数据库错误: {type(db_err).__name__} - {str(db_err)}" # 包含错误类型和具体错误信息
        # 可以考虑添加错误代码（如果驱动提供且认为是安全的）
        # if hasattr(db_err, 'code'): error_detail += f" (Code: {db_err.code})"
        raise HTTPException(status_code=500, detail=error_detail) # 返回 500 错误
    except ConnectionError as conn_err: # 捕获我们自己定义的 Pool 未初始化的错误
         logger.error(f"连接池 '{request.db_name}' 连接错误: {conn_err}")
         raise HTTPException(status_code=503, detail=str(conn_err)) # 返回 503 服务不可用
    except ValueError as val_err: # 捕获例如不支持的数据库类型等配置错误（理论上启动时会捕获）
         logger.error(f"值错误 (可能与配置相关) for '{request.db_name}': {val_err}")
         raise HTTPException(status_code=400, detail=str(val_err)) # 返回 400 错误请求
    # 捕获其他所有未预料到的异常
    # 注意：FastAPI 的通用异常处理器也会捕获这个，但在这里明确处理可以提供更具体的日志
    except Exception as e:
        logger.error(f"执行语句时发生意外错误 on '{request.db_name}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="执行 SQL 命令期间发生意外的内部服务器错误。")


@app.post("/query",
          response_model=QueryResponse, # 定义成功的响应模型
          responses={ # 定义可能的错误响应
              400: {"model": ErrorResponse, "description": "无效请求或非SELECT语句"},
              404: {"model": ErrorResponse, "description": "数据库配置 (db_name) 未找到或未初始化"},
              500: {"model": ErrorResponse, "description": "数据库查询错误或其他内部服务器错误"},
              503: {"model": ErrorResponse, "description": "数据库连接池不可用"}
          },
          summary="执行 SELECT SQL 查询", # API 文档摘要
          description="执行 SELECT 语句。将获取的数据作为字典列表返回。" # API 文档描述
)
async def query_sql(
    request: SQLRequest = Body(...), # 从请求体获取数据
    pool: DatabasePool = Depends(get_db_pool_from_request) # 注入连接池依赖
):
    """
    处理 /query POST 请求。
    """
    logger.info(f"收到 /query 请求，目标数据库: '{request.db_name}', SQL: '{request.sql[:100]}...'")
    try:
        # 检查SQL语句类型，只允许SELECT语句
        sql_upper = request.sql.strip().upper()
        if not sql_upper.startswith('SELECT'):
            error_msg = "非法操作：/query 接口仅支持 SELECT 查询。如需执行其他SQL操作，请使用 /execute 接口。"
            logger.warning(f"尝试通过/query接口执行非SELECT语句: {request.sql[:100]}")
            return JSONResponse(
                status_code=400,
                content=ErrorResponse(message=error_msg).dict()
            )
        
        # 调用连接池的 fetch 方法执行查询
        data = await pool.fetch(request.sql, request.params)
        # 返回包含查询结果的成功响应
        return QueryResponse(message="查询执行成功。", data=data)
    except (oracledb.DatabaseError, asyncpg.PostgresError) as db_err:
        # 处理数据库特定错误
        logger.error(f"在 '{request.db_name}' 上执行查询时数据库错误: {db_err}", exc_info=True)
        error_detail = f"数据库查询错误：{type(db_err).__name__} - {str(db_err)}。请检查SQL语法或数据库状态。"
        return JSONResponse(
            status_code=500,
            content=ErrorResponse(message=error_detail).dict()
        )
    except ConnectionError as conn_err:
         logger.error(f"连接池 '{request.db_name}' 连接错误: {conn_err}")
         return JSONResponse(
             status_code=503,
             content=ErrorResponse(message=f"数据库连接失败：{str(conn_err)}").dict()
         )
    except ValueError as val_err:
         logger.error(f"值错误 (可能与配置相关) for '{request.db_name}': {val_err}")
         return JSONResponse(
             status_code=400,
             content=ErrorResponse(message=f"请求参数错误：{str(val_err)}").dict()
         )
    # 处理其他意外错误
    except Exception as e:
        logger.error(f"执行查询时发生意外错误 on '{request.db_name}': {e}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content=ErrorResponse(message="服务器内部错误，请稍后重试或联系管理员。").dict()
        )

# --- 根路径端点 ---
@app.get("/", response_class=HTMLResponse)
async def root():
    """提供一个美观的HTML欢迎页面。"""
    html_content = """
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>通过API执行SQL</title>
        <style>
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
                line-height: 1.6;
                margin: 0;
                padding: 40px 20px;
                background: #f5f7fa;
                color: #2c3e50;
            }
            .container {
                max-width: 800px;
                margin: 0 auto;
                background: white;
                padding: 40px;
                border-radius: 8px;
                box-shadow: 0 2px 12px rgba(0,0,0,0.1);
            }
            h1 {
                color: #3498db;
                margin-bottom: 30px;
                text-align: center;
            }
            .description {
                color: #666;
                margin-bottom: 30px;
                text-align: center;
            }
            .links {
                display: flex;
                justify-content: center;
                gap: 20px;
                margin-top: 40px;
            }
            .button {
                display: inline-block;
                padding: 12px 24px;
                background: #3498db;
                color: white;
                text-decoration: none;
                border-radius: 6px;
                transition: background 0.3s;
            }
            .button:hover {
                background: #2980b9;
            }
            .warning {
                background: #fff3cd;
                color: #856404;
                padding: 15px;
                border-radius: 6px;
                margin-top: 30px;
                text-align: center;
            }
            .developer-info {
                margin-top: 40px;
                padding: 20px;
                background: #e8f4f8;
                border-radius: 6px;
                text-align: center;
            }
            .developer-info h2 {
                color: #2c3e50;
                margin-bottom: 15px;
                font-size: 1.5em;
            }
            .developer-info p {
                color: #34495e;
                margin: 5px 0;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>SQL执行API</h1>
            <p class="description">通过API对数据库执行SQL命令的服务接口</p>
            <div class="links">
                <a href="/docs" class="button">API文档（Swagger UI）</a>
            </div>
            <div class="warning">
                <strong>安全警告：</strong> 由于存在SQL注入等安全风险，请谨慎使用此API，并确保实施了适当的安全措施。
            </div>
            <div class="developer-info">
                <h2>开发者信息</h2>
                <p>开发者：Zhangzhiao</p>
                <p>项目版本：1.0.0</p>
                <p>联系邮箱：zhangzhiaowork@gmail.com</p>
            </div>
        </div>
    </body>
    </html>
    """
    return html_content

# --- 直接运行应用 (用于开发或简单部署) ---
if __name__ == "__main__":
    import uvicorn
    logger.info("直接通过 __main__ 启动 Uvicorn 服务器...")
    # 注意: 通过这种方式运行时，FastAPI 的启动/关闭事件也能正常工作。
    # 推荐的生产部署方式通常是使用 uvicorn 命令行工具，例如: uvicorn main:app --host 0.0.0.0 --port 8000
    uvicorn.run(
        "main:app", # 指向 FastAPI 应用实例
        host="0.0.0.0", # 监听所有网络接口
        port=8000, # 监听端口
        log_level="info", # Uvicorn 的日志级别
        reload=False # 直接运行时通常不开启 reload
        # reload=True # 开发时可以设为 True，代码更改时自动重启服务器
    )