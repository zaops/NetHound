from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional, Union

class SQLRequest(BaseModel):
    """定义发送到 API 的 SQL 请求结构。"""
    db_name: str = Field(..., description="数据库的逻辑名称 (来自 config.yaml 的键)")
    sql: str = Field(..., description="要执行的 SQL 查询或命令")
    # 参数可以是列表 (用于位置绑定, 如 $1, $2 或 :1, :2)
    # 或字典 (用于命名绑定, 如 :name)
    params: Optional[Union[List[Any], Dict[str, Any]]] = Field(None, description="SQL 查询的参数 (列表用于位置参数, 字典用于命名参数)")

class ExecuteResponse(BaseModel):
    """定义 /execute 端点的成功响应结构。"""
    status: str = "OK"
    message: Optional[str] = Field(None, description="描述性消息")
    rows_affected: Optional[int] = Field(None, description="受 DML 操作影响的行数")

class QueryResponse(BaseModel):
    """定义 /query 端点的成功响应结构。"""
    status: str = "OK"
    message: Optional[str] = Field(None, description="描述性消息")
    data: List[Dict[str, Any]] = Field([], description="查询结果，一个字典列表，每个字典代表一行")

class ErrorResponse(BaseModel):
    """定义 API 错误的响应结构。"""
    status: str = "Error"
    message: str = Field(..., description="错误信息")