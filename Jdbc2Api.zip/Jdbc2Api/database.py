from typing import Dict, Any, List, Tuple, Union
import asyncpg
import oracledb  # 确认导入的是 python-oracledb 库
import logging
import asyncio
from functools import partial

# 配置日志记录器
# 建议在主应用程序 (main.py) 中进行全局配置，这里获取 logger 实例
logger = logging.getLogger(__name__)

# Thin Mode 是默认模式，不再需要全局标志 oracle_client_initialized

class DatabasePool:
    """
    管理不同类型数据库（PostgreSQL, Oracle）的连接池。
    支持异步操作，并为同步的 Oracle 操作使用线程池执行器。
    自动处理 PostgreSQL (UTF-8) 和 Oracle (GBK) 的编码。
    """
    def __init__(self, db_name: str, db_type: str, db_config: dict):
        """
        初始化数据库连接池的基础配置。
        Args:
            db_name (str): 数据库配置的逻辑名称 (来自 config.yaml)。
            db_type (str): 数据库类型 ('postgresql' 或 'oracle')。
            db_config (dict): 包含连接详细信息的字典。
        """
        self.db_name = db_name
        self.db_type = db_type.lower() # 确保类型是小写
        self.config = db_config
        self.pool = None  # 实际的连接池对象，在 init_pool 中创建
        self.loop = asyncio.get_event_loop() # 获取当前事件循环

        # Thin Mode 是 oracledb 的默认行为，不需要特殊初始化。
        # 如果 config.yaml 中错误地包含了 lib_dir，这里也不会使用它。
        logger.debug(f"DatabasePool for '{db_name}' ({self.db_type}) instance created. Ready for pool initialization.")


    async def init_pool(self):
        """异步初始化实际的数据库连接池。"""
        logger.info(f"正在为 '{self.db_name}' ({self.db_type}) 初始化连接池...")
        try:
            if self.db_type == "postgresql":
                # PostgreSQL (假定 UTF-8 编码) - asyncpg 通常自动处理
                self.pool = await asyncpg.create_pool(
                    host=self.config['host'],
                    port=self.config.get('port', 5432),
                    database=self.config['database'],
                    user=self.config['username'],
                    password=self.config['password'],
                    min_size=self.config.get('min_pool_size', 1), # 最小连接数
                    max_size=self.config.get('pool_size', 5),      # 最大连接数
                    # 通常不需要为 UTF-8 显式设置 client_encoding
                    # command_timeout=60 # 可选：设置命令超时
                )
                logger.info(f"PostgreSQL 连接池 '{self.db_name}' 初始化成功 (Host: {self.config['host']}:{self.config.get('port', 5432)}, DB: {self.config['database']})。")

            elif self.db_type == "oracle":
                # Oracle (假定 GBK 编码) - 使用 Thin Mode 并指定编码
                dsn = oracledb.makedsn(
                    host=self.config['host'],
                    port=self.config.get('port', 1521),
                    service_name=self.config.get('service_name'), # 优先使用 Service Name
                    # sid=self.config.get('sid') # 如果提供了 SID 则使用
                )
                # oracledb 的池创建是同步操作，需要在执行器中运行以避免阻塞事件循环
                # 使用偏函数来包装同步的 create_pool 调用
                # 设置 Oracle 客户端环境变量以支持 GBK 字符集
                oracledb.defaults.config_dir = None  # 确保不使用配置文件
                oracledb.defaults.env = {"NLS_LANG": "SIMPLIFIED CHINESE_CHINA.ZHS16GBK"}
                
                create_pool_sync = partial(
                    oracledb.create_pool,
                    user=self.config['username'],
                    password=self.config['password'],
                    dsn=dsn,
                    min=self.config.get('min_pool_size', 1),    # 最小连接数
                    max=self.config.get('pool_size', 5),        # 最大连接数
                    increment=1,                                # 连接增长步长
                    # getmode=oracledb.POOL_GETMODE_WAIT # 可选：池满时的行为
                    # timeout=120 # 可选：获取连接的超时时间
                    # session_callback=init_oracle_session # 可选：初始化会话的回调函数
                )
                logger.info(f"准备为 Oracle ({self.db_name}) 创建连接池 (Thin Mode), DSN: {dsn}, Encoding: GBK, NEncoding: UTF-8")
                # 在默认的线程池执行器中运行同步的池创建函数
                self.pool = await self.loop.run_in_executor(None, create_pool_sync)
                logger.info(f"Oracle 连接池 '{self.db_name}' 初始化成功 (Host: {self.config['host']}:{self.config.get('port', 1521)}, Service/SID: {self.config.get('service_name') or self.config.get('sid')})。")

            else:
                # 如果 config.yaml 中有不支持的类型
                raise ValueError(f"不支持的数据库类型 '{self.db_type}' 配置于 '{self.db_name}'。")

            return True # 返回成功标志

        # --- 更细致的异常处理 ---
        except asyncpg.exceptions.InvalidCatalogNameError as e:
             logger.error(f"初始化 PostgreSQL 连接池 '{self.db_name}' 失败: 数据库 '{self.config['database']}' 不存在或配置错误。", exc_info=True)
             self.pool = None; return False
        except asyncpg.exceptions.InvalidPasswordError as e:
             logger.error(f"初始化 PostgreSQL 连接池 '{self.db_name}' 失败: 用户名或密码错误。", exc_info=True)
             self.pool = None; return False
        except (ConnectionRefusedError, OSError) as e: # 网络连接问题
             logger.error(f"初始化 {self.db_type} 连接池 '{self.db_name}' 失败: 无法连接到数据库服务器 {self.config['host']}:{self.config.get('port') or '默认端口'}。请检查网络和防火墙设置。", exc_info=False) # 通常不需要堆栈
             self.pool = None; return False
        except oracledb.DatabaseError as ora_err:
             # 捕获 Oracle 特定的初始化错误，提供更清晰的日志
             logger.error(f"初始化 Oracle 连接池 '{self.db_name}' 失败: {ora_err}", exc_info=True)
             # 检查常见的连接、认证和编码错误消息
             err_str = str(ora_err).lower()
             if "invalid username/password" in err_str:
                 logger.error("提示: 请检查 Oracle 用户名和密码是否正确。")
             elif "protocol adapter error" in err_str or "connection timed out" in err_str:
                 logger.error(f"提示: 无法连接到 Oracle 监听器 {self.config['host']}:{self.config.get('port', 1521)}。检查监听器状态、网络和防火墙。")
             elif "unknown service name" in err_str or "sid" in err_str:
                  logger.error(f"提示: Oracle 服务名 '{self.config.get('service_name')}' 或 SID '{self.config.get('sid')}' 不正确或数据库未注册到监听器。")
             elif "character set mismatch" in err_str or "encoding" in err_str:
                 logger.error("提示: 错误可能与 Python 端指定的 encoding ('GBK') 或 nencoding ('UTF-8') 与 Oracle 数据库的 NLS 参数不匹配有关。请使用 SQL 查询 NLS_DATABASE_PARAMETERS 确认。")
             self.pool = None
             return False
        except Exception as e: # 捕获其他所有未预料的初始化错误
            logger.error(f"初始化 {self.db_type} 连接池 '{self.db_name}' 时发生未知错误: {e}", exc_info=True)
            self.pool = None
            return False


    def _oracle_execute_sync(self, query: str, params: Union[List, Tuple, Dict]):
        """
        [内部同步方法] 执行 Oracle DML/DDL 语句。
        此方法会在线程池中运行。
        oracledb 驱动根据初始化时设置的编码自动处理 Python str (UTF-8) 与 Oracle (GBK) 之间的数据转换。
        """
        conn = None
        cursor = None
        try:
            # 从池中获取连接 (同步)
            # logger.debug(f"Oracle ({self.db_name}): Acquiring connection from pool.")
            conn = self.pool.acquire()
            # logger.debug(f"Oracle ({self.db_name}): Connection acquired.")
            cursor = conn.cursor()
            # 根据参数类型 (字典或列表/元组) 选择执行方式
            if isinstance(params, dict):
                 # 使用命名参数 (例如 :name), 驱动会将 UTF-8 str 编码为 GBK
                 cursor.execute(query, params)
            else:
                 # 使用位置参数 (例如 :1, :2) 或无参数, 驱动会将 UTF-8 str 编码为 GBK
                 cursor.execute(query, params or []) # 如果 params 为 None, 传递空列表
            rows_affected = cursor.rowcount # 获取影响的行数
            conn.commit() # 提交事务
            # 日志中的 params 是 Python 的 UTF-8 字符串
            logger.info(f"Oracle Execute SQL: {query}, 参数: {params}, 影响行数: {rows_affected}")
            return rows_affected # 返回影响的行数
        except oracledb.DatabaseError as db_err:
            logger.error(f"Oracle ({self.db_name}) 执行 SQL 时数据库错误: {db_err}", exc_info=True)
            err_str = str(db_err).lower()
            if "invalid identifier" in err_str: logger.warning("提示: SQL 语法错误，可能列名或表名无效。")
            elif "unique constraint" in err_str: logger.warning("提示: 违反唯一约束。")
            if conn:
                try:
                    conn.rollback() # 发生错误时回滚
                except oracledb.DatabaseError as rb_err:
                    logger.error(f"Oracle ({self.db_name}): 回滚事务时出错: {rb_err}", exc_info=True)
            raise # 重新引发数据库特定错误，上层会处理
        except Exception as e: # 其他非数据库错误
            logger.error(f"Oracle ({self.db_name}) 执行 SQL 时发生通用错误: {e}", exc_info=True)
            if conn:
                try: conn.rollback()
                except Exception: pass # 忽略回滚中的错误
            raise # 重新引发通用错误
        finally:
            # 确保游标和连接被关闭/释放
            if cursor:
                try: cursor.close()
                except Exception as cur_err: logger.warning(f"Oracle ({self.db_name}): 关闭游标时出错: {cur_err}")
            if conn:
                try:
                    # logger.debug(f"Oracle ({self.db_name}): Releasing connection to pool.")
                    self.pool.release(conn) # 将连接释放回池中
                    # logger.debug(f"Oracle ({self.db_name}): Connection released.")
                except Exception as rel_err: logger.error(f"Oracle ({self.db_name}): 释放连接到池时出错: {rel_err}")


    def _oracle_fetch_sync(self, query: str, params: Union[List, Tuple, Dict]):
        """
        [内部同步方法] 执行 Oracle SELECT 查询并获取所有结果。
        此方法会在线程池中运行。
        oracledb 驱动根据初始化时设置的编码自动将 Oracle (GBK) 数据解码为 Python str (UTF-8)。
        """
        conn = None
        cursor = None
        try:
            # logger.debug(f"Oracle ({self.db_name}): Acquiring connection for fetch.")
            conn = self.pool.acquire()
            # logger.debug(f"Oracle ({self.db_name}): Connection acquired for fetch.")
            cursor = conn.cursor()
            # 根据参数类型 (字典或列表/元组) 选择执行方式
            if isinstance(params, dict):
                 cursor.execute(query, params) # 驱动将 UTF-8 参数编码为 GBK
            else:
                 cursor.execute(query, params or [])

            # 获取列名，用于创建字典列表 (转换为小写以保持一致性)
            columns = [col[0].lower() for col in cursor.description] if cursor.description else []
            # 获取所有行 (作为元组)，然后转换为字典列表
            # 使用游标分批获取数据，避免一次性获取大量数据导致内存问题
            result = []
            batch_size = 100
            while True:
                batch = cursor.fetchmany(batch_size)
                if not batch:
                    break
                result.extend([dict(zip(columns, row)) for row in batch])
            
            # 日志中的 params 和 result 中的字符串都是 Python 的 UTF-8 字符串
            logger.info(f"Oracle Fetch SQL: {query}, 参数: {params}, 获取行数: {len(result)}")
            return result
        except oracledb.DatabaseError as db_err:
            logger.error(f"Oracle ({self.db_name}) 查询 SQL 时数据库错误: {db_err}", exc_info=True)
            raise # 重新引发数据库特定错误
        except Exception as e:
            logger.error(f"Oracle ({self.db_name}) 查询 SQL 时发生通用错误: {e}", exc_info=True)
            raise # 重新引发通用错误
        finally:
            # 确保游标和连接被关闭/释放
            if cursor:
                try: cursor.close()
                except Exception as cur_err: logger.warning(f"Oracle ({self.db_name}): 关闭查询游标时出错: {cur_err}")
            if conn:
                try:
                    # logger.debug(f"Oracle ({self.db_name}): Releasing connection after fetch.")
                    self.pool.release(conn)
                    # logger.debug(f"Oracle ({self.db_name}): Connection released after fetch.")
                except Exception as rel_err: logger.error(f"Oracle ({self.db_name}): 释放查询连接到池时出错: {rel_err}")


    async def execute(self, query: str, params: Union[List, Tuple, Dict] = None) -> int:
        """
        异步执行 DML/DDL (INSERT, UPDATE, DELETE, CREATE 等) 语句。
        根据数据库类型调用相应的底层方法。
        Args:
            query (str): 要执行的 SQL 语句。
            params (Union[List, Tuple, Dict], optional): SQL 语句的参数。
                PostgreSQL 使用位置参数 ($1, $2)，应提供 List 或 Tuple。
                Oracle 可使用位置参数 (:1, :2) 或命名参数 (:name)，可提供 List/Tuple 或 Dict。
                默认为 None。
        Returns:
            int: 受影响的行数。
        Raises:
            ConnectionError: 如果连接池未初始化或无效。
            ValueError: 如果数据库类型不支持。
            asyncpg.PostgresError: 如果 PostgreSQL 执行出错。
            oracledb.DatabaseError: 如果 Oracle 执行出错 (通过内部同步方法抛出)。
            Exception: 其他意外错误。
        """
        if not self.pool:
            # 这个检查理论上不应触发，因为 FastAPI 依赖会先检查
            logger.critical(f"尝试在未初始化的连接池 '{self.db_name}' 上执行操作！")
            raise ConnectionError(f"数据库连接池 '{self.db_name}' 未初始化或无效。")

        # 确保 params 对于不需要参数的查询是空列表/字典，以便底层驱动正确处理
        # 对于 Oracle 的 Dict 参数，None 也是可接受的，但为了统一，我们这样做
        # if params is None:
        #     params = {} if self.db_type == "oracle" and isinstance(params, dict) else [] # 更严谨的判断，但通常 [] 即可
        effective_params = params or ([] if not isinstance(params, dict) else {}) # 适应 Oracle 字典

        if self.db_type == "postgresql":
            # 使用 asyncpg 异步执行
            async with self.pool.acquire() as connection:
                try:
                    # asyncpg 要求位置参数是 list 或 tuple
                    pg_params = effective_params if isinstance(effective_params, (list, tuple)) else list(effective_params.values()) if isinstance(effective_params, dict) else []
                    # execute 返回状态字符串，例如 'INSERT 0 1'
                    status_str = await connection.execute(query, *pg_params)
                    logger.info(f"PostgreSQL Execute SQL: {query}, 参数: {pg_params}, 状态: {status_str}")
                    # 尝试解析影响的行数 (尽力而为)
                    try:
                        parts = status_str.split()
                        if len(parts) > 0 and parts[-1].isdigit():
                            return int(parts[-1])
                        else: # 例如 CREATE TABLE 等可能不返回数字
                            logger.debug(f"PostgreSQL status '{status_str}' 未包含行数信息，返回 0。")
                            return 0
                    except Exception:
                         logger.warning(f"无法从状态 '{status_str}' 解析 PostgreSQL 影响的行数。")
                         return 0 # 无法解析时返回 0
                except asyncpg.PostgresError as pg_err:
                    # asyncpg 错误通常包含有用的上下文
                    logger.error(f"PostgreSQL ({self.db_name}) 执行 SQL 时数据库错误: {pg_err}", exc_info=True)
                    raise # 重新引发 PostgreSQL 错误，上层会处理

        elif self.db_type == "oracle":
            # 在线程池执行器中运行同步的 Oracle 代码
            try:
                result = await self.loop.run_in_executor(
                    None,  # 使用默认执行器 (通常是 ThreadPoolExecutor)
                    self._oracle_execute_sync, # 要运行的同步函数
                    query, # 传递给同步函数的参数
                    effective_params # 传递给同步函数的参数 (可以是 list/tuple/dict)
                )
                return result # _oracle_execute_sync 返回影响的行数
            except oracledb.DatabaseError:
                 # 错误已经在 _oracle_execute_sync 中记录，直接重新抛出
                 raise
            except Exception as e:
                 # 捕获 run_in_executor 本身或 _oracle_execute_sync 中的非数据库异常
                 logger.error(f"Oracle ({self.db_name}) 执行 SQL 时在 executor 中发生错误: {e}", exc_info=True)
                 raise

        else:
             # 这个分支理论上不应到达，因为类型在初始化时检查
             logger.error(f"执行操作遇到不支持的数据库类型 '{self.db_type}' for pool '{self.db_name}'")
             raise ValueError(f"执行操作不支持的数据库类型: {self.db_type}")


    async def fetch(self, query: str, params: Union[List, Tuple, Dict] = None) -> List[Dict[str, Any]]:
        """
        异步执行 SELECT 查询并获取所有结果。
        根据数据库类型调用相应的底层方法。
        Args:
            query (str): 要执行的 SELECT SQL 语句。
            params (Union[List, Tuple, Dict], optional): SQL 语句的参数 (用法同 execute)。默认为 None。
        Returns:
            List[Dict[str, Any]]: 一个字典列表，每个字典代表一行数据，键是小写的列名。结果中的字符串是 Python str (UTF-8)。
        Raises:
            ConnectionError: 如果连接池未初始化或无效。
            ValueError: 如果数据库类型不支持。
            asyncpg.PostgresError: 如果 PostgreSQL 查询出错。
            oracledb.DatabaseError: 如果 Oracle 查询出错 (通过内部同步方法抛出)。
            Exception: 其他意外错误。
        """
        if not self.pool:
            logger.critical(f"尝试在未初始化的连接池 '{self.db_name}' 上执行查询！")
            raise ConnectionError(f"数据库连接池 '{self.db_name}' 未初始化或无效。")

        effective_params = params or ([] if not isinstance(params, dict) else {})

        if self.db_type == "postgresql":
             # 使用 asyncpg 异步查询
             async with self.pool.acquire() as connection:
                try:
                    pg_params = effective_params if isinstance(effective_params, (list, tuple)) else list(effective_params.values()) if isinstance(effective_params, dict) else []
                    # fetch 返回 asyncpg.Record 对象列表
                    records = await connection.fetch(query, *pg_params)
                    # 将 asyncpg.Record 转换为字典列表 (结果是 Python str, UTF-8)
                    result = [dict(record) for record in records]
                    logger.info(f"PostgreSQL Fetch SQL: {query}, 参数: {pg_params}, 获取行数: {len(result)}")
                    return result
                except asyncpg.PostgresError as pg_err:
                    logger.error(f"PostgreSQL ({self.db_name}) 查询 SQL 时数据库错误: {pg_err}", exc_info=True)
                    raise # 重新引发 PostgreSQL 错误

        elif self.db_type == "oracle":
            # 在线程池执行器中运行同步的 Oracle 查询代码
            try:
                result = await self.loop.run_in_executor(
                    None, # 使用默认执行器
                    self._oracle_fetch_sync, # 要运行的同步函数
                    query, # 传递给同步函数的参数
                    effective_params # 传递给同步函数的参数 (可以是 list/tuple/dict)
                )
                # result 已经是包含 Python str (UTF-8) 的字典列表
                return result
            except oracledb.DatabaseError:
                 # 错误已在 _oracle_fetch_sync 中记录
                 raise
            except Exception as e:
                 logger.error(f"Oracle ({self.db_name}) 查询 SQL 时在 executor 中发生错误: {e}", exc_info=True)
                 raise
        else:
            logger.error(f"查询操作遇到不支持的数据库类型 '{self.db_type}' for pool '{self.db_name}'")
            raise ValueError(f"查询操作不支持的数据库类型: {self.db_type}")


    async def close(self):
        """异步关闭数据库连接池。"""
        if not self.pool:
            logger.warning(f"尝试关闭未初始化或已关闭的连接池 '{self.db_name}'。")
            return

        logger.info(f"正在关闭 {self.db_type} 连接池 '{self.db_name}'...")
        pool_to_close = self.pool
        self.pool = None # 立即将 self.pool 设为 None，防止关闭过程中新的请求使用它

        try:
            if self.db_type == "postgresql":
                # asyncpg 的 close 是异步的
                await pool_to_close.close()
                logger.info(f"PostgreSQL 连接池 '{self.db_name}' 已关闭。")
            elif self.db_type == "oracle":
                # oracledb 的 close 是同步的，在执行器中运行
                close_sync = partial(pool_to_close.close, True) # 使用 partial 传递 nowait=True 参数
                await self.loop.run_in_executor(None, close_sync)
                logger.info(f"Oracle 连接池 '{self.db_name}' 已关闭。")
        except Exception as e:
            logger.error(f"关闭 {self.db_type} 连接池 '{self.db_name}' 时出错: {e}", exc_info=True)
        # finally:
            # self.pool = None # 在开始时就设置了 None