```
unzip packages.zip 

rm -rf venv/
python3.12 -m venv venv

source venv/bin/activate
pip3.12 install --no_index --find_links=./packages pip==25.0.1

pip3.12 install  --no-index  --find-links=./packages  -r requirements.txt
```