# SQL 执行 API 文档

## 概述

通过 API 对已配置的数据库执行 SQL 命令。**警告：** 由于安全风险，请极其谨慎使用。

## API 端点

### 执行 DML/DDL SQL 语句

- **路径**: `/execute`
- **方法**: POST
- **描述**: 执行 INSERT, UPDATE, DELETE, CREATE TABLE 等修改数据或模式的 SQL 语句。返回受影响的行数。
- **请求体**:
  ```json
  {
    "db_name": "数据库配置名称",
    "sql": "SQL语句",
    "params": "参数(可选)"
  }
  ```
- **成功响应**:
  ```json
  {
    "message": "命令执行成功。",
    "rows_affected": 受影响的行数
  }
  ```
- **错误响应**:
  - 400: 无效请求 (例如，缺少字段、格式错误)
  - 404: 指定的数据库配置 (db_name) 未找到或未初始化
  - 500: 数据库执行错误或其他内部服务器错误
  - 503: 数据库连接池不可用 (例如，初始化失败)

### 执行 SELECT SQL 查询

- **路径**: `/query`
- **方法**: POST
- **描述**: 执行 SELECT 语句。将获取的数据作为字典列表返回。
- **请求体**:
  ```json
  {
    "db_name": "数据库配置名称",
    "sql": "SQL语句",
    "params": "参数(可选)"
  }
  ```
- **成功响应**:
  ```json
  {
    "message": "查询执行成功。",
    "data": [查询结果]
  }
  ```
- **错误响应**:
  - 400: 无效请求
  - 404: 数据库配置 (db_name) 未找到或未初始化
  - 500: 数据库查询错误或其他内部服务器错误
  - 503: 数据库连接池不可用

### 根路径

- **路径**: `/`
- **方法**: GET
- **描述**: 提供一个简单的根路径响应，表明 API 正在运行。
- **响应**:
  ```json
  {
    "message": "SQL 执行 API 正在运行。请访问 /docs 查看 API 文档。"
  }
  ```

## 错误处理

所有错误响应都遵循以下格式:
```json
{
  "message": "错误描述"
}
```

## 参数占位符说明

不同数据库使用不同的参数占位符格式：

- PostgreSQL: 使用 `$1`, `$2`, `$3` 等作为参数占位符
- Oracle: 使用 `:1`, `:2`, `:3` 等作为参数占位符

## 示例

### PostgreSQL示例

#### 执行更新
```bash
curl -X POST http://localhost:8000/execute \
  -H "Content-Type: application/json" \
  -d '{"db_name":"postgres_db","sql":"UPDATE users SET name = $1 WHERE id = $2","params":["新名字",1]}'
```

#### 执行查询
```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"db_name":"postgres_db","sql":"SELECT * FROM users WHERE id = $1","params":[1]}'
```

### Oracle示例

#### 执行更新
```bash
curl -X POST http://localhost:8000/execute \
  -H "Content-Type: application/json" \
  -d '{"db_name":"oracle_db","sql":"UPDATE users SET name = :1 WHERE id = :2","params":["新名字",1]}'
```

#### 执行查询
```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"db_name":"oracle_db","sql":"SELECT * FROM users WHERE id = :1","params":[1]}'
```
```