# JDBC2API 项目

## 项目概述

这是一个通过FastAPI提供RESTful接口来执行数据库操作的应用程序，支持PostgreSQL和Oracle数据库。

## 环境准备

1. 创建Python虚拟环境
```bash
python -m venv venv
```

2. 激活虚拟环境
- Windows:
```bash
venv\Scripts\activate
```
- Linux/MacOS:
```bash
source venv/bin/activate
```

## 安装依赖

```bash
pip install -r requirements.txt
```

## 配置文件

在项目根目录创建`config.yaml`文件，配置数据库连接信息。示例配置：

```yaml
databases:
  postgres_db:
    type: postgresql
    host: your_postgres_host
    port: 5432
    database: your_database
    username: your_username
    password: your_password
  oracle_db:
    type: oracle
    host: your_oracle_host
    port: 1521
    service_name: your_service_name
    username: your_username
    password: your_password
```

## 运行API

```bash
uvicorn main:app --reload
```

## API端点

- `POST /execute`: 执行DML/DDL语句
- `POST /query`: 执行SELECT查询

访问`http://localhost:8000/docs`查看Swagger文档。

## 注意事项

1. 确保数据库服务可访问
2. 生产环境请配置适当的权限和安全措施
3. 敏感信息建议使用环境变量而非直接写在配置文件中