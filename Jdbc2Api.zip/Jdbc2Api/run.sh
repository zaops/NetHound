#!/bin/bash

# 激活虚拟环境
source venv/bin/activate

# 默认主机和端口
HOST="127.0.0.1"
PORT="8000"
RELOAD_FLAG="" # 默认不开启热重载
LOG_FILE="app.log" # 日志文件

# 解析命令行参数 (可选)
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --host) HOST="$2"; shift ;;      # 设置监听主机
        --port) PORT="$2"; shift ;;      # 设置监听端口
        --reload) RELOAD_FLAG="--reload";; # 开启热重载
        --log) LOG_FILE="$2"; shift ;;   # 设置日志文件
        *) echo "未知参数: $1"; exit 1 ;;
    esac
    shift
done

echo "启动 FastAPI SQL API，监听地址: http://${HOST}:${PORT}"
echo "配置文件: config.yaml"
echo "FastAPI 应用: main:app"
echo "日志文件: ${LOG_FILE}"
if [ -n "$RELOAD_FLAG" ]; then
  echo "热重载已启用"
else
  echo "热重载未启用"
fi

# 使用nohup后台运行uvicorn，并重定向输出到日志文件
nohup uvicorn main:app --host "${HOST}" --port "${PORT}" ${RELOAD_FLAG} > "${LOG_FILE}" 2>&1 &

# 输出进程ID
echo "应用已在后台启动，进程ID: $!"